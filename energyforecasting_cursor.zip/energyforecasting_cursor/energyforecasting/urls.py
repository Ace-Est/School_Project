"""
URL configuration for energyforecasting project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/4.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from modelapp.views import dashboard, PredictionView, InfluxDBView, daily_chart_view, monitor_status, energy_storage_simulation, prediction_storage_simulation


urlpatterns = [
    path('admin/', admin.site.urls),
    path('', dashboard, name='dashboard'),  # 將 dashboard 設為根路徑
    path('predict/', PredictionView.as_view(), name='predict'),
    path('influxdb/', InfluxDBView.as_view(), name='influxdb_query'),
    path('daily-chart/', daily_chart_view, name='daily_chart'),
    path('monitor/', monitor_status, name='monitor_status'),
    path('energy-storage/', energy_storage_simulation, name='energy_storage'),
    path('prediction-storage/', prediction_storage_simulation, name='prediction_storage'),
]
