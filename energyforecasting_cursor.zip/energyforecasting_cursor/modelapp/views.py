import pandas as pd
import numpy as np
from tensorflow import keras
from django.shortcuts import render
from django.conf import settings
from django.views import View
from django.db import connection
from .forms import CSVUploadForm
import joblib
import io
import base64
import json
from influxdb import InfluxDBClient
from datetime import datetime, timedelta
import logging
logger = logging.getLogger(__name__)

class PredictionView(View):
    def get(self, request):
        form = CSVUploadForm()
        return render(request, 'upload.html', {'form': form})

    def post(self, request):
        form = CSVUploadForm(request.POST, request.FILES)
        if form.is_valid():
            csv_file = request.FILES['csv_file']
            df = pd.read_csv(csv_file, parse_dates=['Time'], index_col=[0])
            
            # 載入模型資訊
            model_info = joblib.load(settings.MODEL_INFO_PATH)
            
            # 載入模型和 scaler
            model = keras.models.load_model(settings.BASE_DIR / 'ml_models' / model_info['model_filename'])
            scaler = joblib.load(settings.BASE_DIR / 'ml_models' / model_info['scaler_filename'])
            
            # 數據預處理和預測
            predictions, chart_data = self.predict(df, model, scaler)
            
            # 打印 chart_data 以進行調試
            print("Chart Data:", chart_data[:10])  # 只打印前10個數據點
            
            # 準備結果數據
            result_data = [
                {'time': df.index[-len(predictions):][i].strftime('%Y-%m-%d %H:%M:%S'),
                 'prediction': round(float(pred), 2)}
                for i, pred in enumerate(predictions)
            ]
            
            return render(request, 'result.html', {
                'chart_data': chart_data,
                'result_data': result_data,
                'file_name': csv_file.name
            })
        
        return render(request, 'upload.html', {'form': form})

    def predict(self, df, model, scaler):
        # 选择特征列
        feature_columns = ['kpt', 'Temperature', 'Humidity', 'Rain', 'day_of_week', 'day_off', 'Month', 'Day', 'Hour', 'Minute']
        
        # 对数据进行缩放
        scaled_data = scaler.transform(df[feature_columns])
        
        # 准备输入数据
        X = []
        for i in range(96, len(scaled_data)):
            X.append(scaled_data[i-96:i])
        X = np.array(X)
        
        # 进预测
        predictions = model.predict(X)
        
        # 反向缩放预测结果（只针对 kpt 列）
        predictions_rescaled = scaler.inverse_transform(
            np.hstack([predictions, np.zeros((len(predictions), len(feature_columns)-1))])
        )[:, 0]
        
        # 获取对应的时间索引并延后一天
        original_times = df.index[-len(predictions):]
        time_index = [time + timedelta(days=1) for time in original_times]
        
        # 打印时间变化
        print("原始时间:", original_times[0])
        print("延后时间:", time_index[0])

        chart_data = [
            [time.timestamp() * 1000, float(pred)]  # 转换为 JavaScript 时间戳
            for time, pred in zip(time_index, predictions_rescaled)
        ]

        # 打印chart_data的第一个时间点
        print("Chart data first point:", chart_data[0])

        return predictions_rescaled, json.dumps(chart_data)
    
class InfluxDBView(View):
    def get(self, request):
        time_range = request.GET.get('time_range', 'day')
        end_time = datetime.now().replace(hour=0, minute=0, second=0, microsecond=0) - timedelta(hours=8)
        
        if time_range == 'day':
            start_time = end_time - timedelta(days=1)
            date_display = end_time.strftime('%Y-%m-%d')
        elif time_range == 'week':
            start_time = end_time - timedelta(days=7)
            date_display = f"{start_time.strftime('%Y-%m-%d')} 至 {end_time.strftime('%Y-%m-%d')}"
        elif time_range == 'month':
            start_time = end_time - timedelta(days=30)
            date_display = f"{start_time.strftime('%Y-%m-%d')} 至 {end_time.strftime('%Y-%m-%d')}"
        else:
            start_time = end_time - timedelta(days=1)  # 默認為一天
            date_display = end_time.strftime('%Y-%m-%d')

        chart_data = self.get_chart_data(start_time, end_time)
        chart_data['time_range'] = time_range
        chart_data['date_display'] = date_display
        return render(request, 'influxdb_query.html', chart_data)

    def get_chart_data(self, start_time, end_time):
        client = InfluxDBClient('120.107.146.56', 8086, 'vendor01', 'q1a2z3wsx', 'Building_PV')
        
        # 定義表格名稱與顯示名稱的映射
        table_names = {
            "HT4_1": "教學一二館",
            "HT5": "經世館",
            "HT6": "力行館",
            "HT7_9": "第十宿舍",
            "HT8": "工學院"
        }
        
        tables = ["HT4_1", "HT5", "HT6", "HT7_9", "HT8"]
        results = {}
        total_sum = 0

        for table in tables:
            if table == "HT4_1":
                # 改為實際查 HT8 原始資料，不做運算
                query_table = "HT8"
            else:
                query_table = table

            query = f"""
            SELECT MEAN(P_sum) AS avg_P_sum
            FROM "{query_table}"
            WHERE time >= '{start_time.strftime('%Y-%m-%dT%H:%M:%SZ')}' AND time < '{end_time.strftime('%Y-%m-%dT%H:%M:%SZ')}'
            GROUP BY time(15m)
            """
            result = client.query(query)
            points = list(result.get_points())

            if table == "HT4_1":
                # 對 HT4_1 (實際是HT8查回來的) 做換算
                for point in points:
                    if point['avg_P_sum'] is not None:
                        point['avg_P_sum'] = point['avg_P_sum'] / 139.5 * 69.75

            results[table] = points
            total_sum += sum(point['avg_P_sum'] for point in points if point['avg_P_sum'] is not None)

        # 使用映射的名稱來建立圓餅圖數據
        pie_data = [{'name': table_names[table], 'y': sum(point['avg_P_sum'] for point in points if point['avg_P_sum'] is not None) / total_sum * 100} for table, points in results.items()]

        categories = []
        line_data = []
        
        for point in results[tables[0]]:
            if point['avg_P_sum'] is not None:
                time = (datetime.strptime(point['time'], '%Y-%m-%dT%H:%M:%SZ') + timedelta(hours=8)).strftime('%Y-%m-%d %H:%M:%S')
                categories.append(time)

        # 使用映射的名稱來建立折線圖數據
        for table in tables:
            series_data = []
            for point in results[table]:
                if point['avg_P_sum'] is not None:
                    series_data.append(float(point['avg_P_sum']))
            line_data.append({
                'name': table_names[table],  # 使用映射的名稱
                'data': series_data
            })

        client.close()

        return {
            'pie_data': json.dumps(pie_data),
            'line_data': json.dumps(line_data),
            'categories': json.dumps(categories)
        }
    
def daily_chart_view(request):
    # 獲取選擇的日期，如果沒有選擇，則使用昨天的日期
    selected_date = request.GET.get('date')
    if selected_date:
        target_date = datetime.strptime(selected_date, '%Y-%m-%d')
    else:
        target_date = datetime.now().replace(hour=0, minute=0, second=0, microsecond=0) - timedelta(days=1)

    # 設置查詢的開始和結束時間
    start_time = target_date
    end_time = target_date + timedelta(days=1)

    # 執行 TimescaleDB SQL 查詢
    with connection.cursor() as cursor:
        query = """
            SET TIMEZONE = 'Asia/Taipei';
            SELECT time_bucket('15 minutes', time) AS time_bucket, 
                   ROUND(AVG(kpt)) AS avg_kpt
            FROM "main_ht0"
            WHERE time >= %s AND time < %s
            GROUP BY time_bucket
            ORDER BY time_bucket;
        """
        logger.info(f"TimescaleDB Query: {query}")
        logger.info(f"Query parameters: start_time={start_time}, end_time={end_time}")
        cursor.execute(query, [start_time, end_time])

        result = cursor.fetchall()
        
    categories = [row[0].strftime('%H:%M') for row in result]
    kpt_values = [row[1] for row in result]
    
    try:
        pv_values = query_influx_with_timezone_adjustment(start_time, end_time)

        if len(kpt_values) == len(pv_values):
            sum_values = [kpt + pv for kpt, pv in zip(kpt_values, pv_values)]
            chart_data = {
                'categories': categories,
                'sum_values': sum_values,
                'pv_values': pv_values,
            }
            
            # 計算電費
            fee_data = calculate_hourly_electricity_fee(sum_values, categories, target_date)
        else:
            logger.error(f"數據長度不匹配: kpt_values={len(kpt_values)}, pv_values={len(pv_values)}")
            chart_data = {
                'categories': categories,
                'sum_values': kpt_values,  # 只顯示 kpt 數據
                'pv_values': [0] * len(categories),  # 用 0 填充 PV 數據
            }
            fee_data = None
    except Exception as e:
        logger.error(f"處理數據時發生錯誤: {str(e)}")
        chart_data = {
            'categories': categories,
            'sum_values': kpt_values,
            'pv_values': [0] * len(categories),
        }
        fee_data = None

    context = {
        'chart_data': chart_data,
        'selected_date': target_date.strftime('%Y-%m-%d'),
        'fee_data': fee_data,
        'error_message': '數據不完整，部分數據可能無法顯示' if not fee_data else None
    }
    
    return render(request, 'daily_chart.html', context)

def query_influx_with_timezone_adjustment(start_time, end_time):
    client = InfluxDBClient('120.107.146.56', 8086, 'vendor01', 'q1a2z3wsx', 'Building_PV')

    # 调整查询时间，减去 8 小时
    query_start = (start_time - timedelta(hours=8)).strftime('%Y-%m-%dT%H:%M:%SZ')
    query_end = (end_time - timedelta(hours=8)).strftime('%Y-%m-%dT%H:%M:%SZ')

    query = f"""
    SELECT MEAN(P_sum) AS avg_P_sum
    FROM "HT4_1", "HT5", "HT6", "HT7_9", "HT8"
    WHERE time >= '{query_start}' AND time < '{query_end}'
    GROUP BY time(15m)
    """
    logger.info(f"InfluxDB Query: {query}")

    result = client.query(query)

    adjusted_results = []
    for point in result.get_points():
        adjusted_time = datetime.strptime(point['time'], '%Y-%m-%dT%H:%M:%SZ') + timedelta(hours=8)
        point['avg_P_sum'] = point['avg_P_sum'] if point['avg_P_sum'] is not None else 0
        adjusted_results.append({
            'time': adjusted_time,
            'avg_P_sum': point['avg_P_sum']
        })

    client.close()

    logger.info(f"InfluxDB query result length: {len(adjusted_results)}")

    # 计算每个时间点应该有多少组数据
    expected_points = len(adjusted_results) // 5
    logger.info(f"Expected points per group: {expected_points}")
    for i in range(expected_points):
        adjusted_results[i]['avg_P_sum'] = adjusted_results[i+expected_points*4]['avg_P_sum'] / 139.5*69.75
    # 初始化用于存储结果的列表
    aggregated_results = [0] * expected_points

    # 将数据分为 5 组，每组进行累加
    for group_index in range(5):
        group_start = group_index * expected_points
        group_end = group_start + expected_points

        # 遍历每个时间段，并累加 5 组的值
        for i in range(expected_points):
            if group_start + i < len(adjusted_results):
                aggregated_results[i] += adjusted_results[group_start + i]['avg_P_sum']

    return aggregated_results

def get_daily_chart_data(target_date=None):
    if target_date is None:
        target_date = datetime.now().replace(hour=0, minute=0, second=0, microsecond=0) - timedelta(days=1)
    
    start_time = target_date
    end_time = target_date + timedelta(days=1)

    # 直接執行 TimescaleDB SQL 查詢
    with connection.cursor() as cursor:
        query = """
            SET TIMEZONE = 'Asia/Taipei';           
            SELECT time_bucket('15 minutes', time) AS time_bucket, 
                   ROUND(AVG(kpt)) AS avg_kpt
            FROM "main_ht0"
            WHERE time >= %s AND time < %s
            GROUP BY time_bucket
            ORDER BY time_bucket;
        """
        logger.info(f"TimescaleDB Query: {query}")
        logger.info(f"Query parameters: start_time={start_time}, end_time={end_time}")
        cursor.execute(query, [start_time, end_time])

        result = cursor.fetchall()
        
    categories = [row[0].strftime('%H:%M') for row in result]
    kpt_values = [row[1] for row in result]
    
    pv_values = query_influx_with_timezone_adjustment(start_time, end_time)

    if len(kpt_values) == len(pv_values):
        sum_values = [kpt + pv for kpt, pv in zip(kpt_values, pv_values)]
    else:
        raise ValueError(f"數據長度不匹配，無法計算差異。kpt_values: {len(kpt_values)}, pv_values: {len(pv_values)}")

    chart_data = {
        'categories': categories,
        'sum_values': sum_values,
        'pv_values': pv_values,
    }

    return chart_data

def dashboard(request):
    # 获取当前时间
    current_time = datetime.now()
    
    # 设置当天的开始时间（0点）
    start_time = current_time.replace(hour=0, minute=0, second=0, microsecond=0)
    
    # 使用当前时间作为结束时间，并向下取整到最近的15分钟
    end_time = current_time.replace(
        minute=(current_time.minute // 15) * 15,
        second=0,
        microsecond=0
    )

    # 执行 TimescaleDB SQL 查询
    with connection.cursor() as cursor:
        query = """
            SET TIMEZONE = 'Asia/Taipei';
            SELECT time_bucket('15 minutes', time) AS time_bucket, 
                   ROUND(AVG(kpt)) AS avg_kpt
            FROM "main_ht0"
            WHERE time >= %s AND time <= %s
            GROUP BY time_bucket
            ORDER BY time_bucket;
        """
        logger.info(f"TimescaleDB Query: {query}")
        logger.info(f"Query parameters: start_time={start_time}, end_time={end_time}")
        cursor.execute(query, [start_time, end_time])

        result = cursor.fetchall()
    
    logger.info(f"TimescaleDB Query result length: {len(result)}")
    logger.info(f"First few results: {result[:5]}")

    if not result:
        logger.warning("No data returned from TimescaleDB query")
        return render(request, 'dashboard.html', {
            'error_message': '暂无数据',
            'selected_date': current_time.strftime('%Y-%m-%d')
        })

    categories = [row[0].strftime('%H:%M') for row in result]
    kpt_values = [row[1] for row in result]
    
    # 调整 InfluxDB 查询时间范围
    pv_values = query_influx_with_timezone_adjustment(start_time, end_time)

    logger.info(f"KPT values length: {len(kpt_values)}")
    logger.info(f"PV values length: {len(pv_values)}")

    if len(kpt_values) != len(pv_values):
        logger.error(f"Data length mismatch: kpt_values={len(kpt_values)}, pv_values={len(pv_values)}")
        # 调整数组长度以匹配
        min_length = min(len(kpt_values), len(pv_values))
        kpt_values = kpt_values[:min_length]
        pv_values = pv_values[:min_length]
        categories = categories[:min_length]

    sum_values = [kpt + pv for kpt, pv in zip(kpt_values, pv_values)]

    chart_data = {
        'categories': categories,
        'sum_values': sum_values,
        'pv_values': pv_values,
    }

    logger.info(f"Chart data prepared: {len(categories)} data points")

    return render(request, 'dashboard.html', {
        'chart_data': json.dumps(chart_data),
        'selected_date': current_time.strftime('%Y-%m-%d')
    })

def calculate_hourly_electricity_fee(sum_values, categories, target_date):
    """
    計算電費的函數
    """
    logger.info(f"\n{'='*50}")
    logger.info(f"開始計算 {target_date.strftime('%Y-%m-%d')} 的電費")
    logger.info(f"{'='*50}")
    
    # 契約容量及基本電費設定
    contract_capacity = 785  # kW
    basic_fee_summer = 233.6  # 月每 kW 的基本電費
    basic_fee_non_summer = 166.9  # 非夏月每 kW 的基本電費

    # 定義每個時段的電價
    rate_table = {
        "peak": {"summer": 5.8, "non_summer": None},
        "half_peak": {
            "summer": {"weekday": 3.63, "saturday": 1.78},
            "non_summer": {"weekday": 3.4, "saturday": 1.65}
        },
        "off_peak": {"summer": 1.58, "non_summer": 1.45}
    }

    # 將96筆數據轉換為24筆小時數據，並記錄約時間
    hourly_data = []
    max_usage = 0  # 記錄最大用電量
    over_contract_times = []  # 記錄超約時間

    for i in range(0, 96, 4):
        hour_avg = sum(sum_values[i:i+4]) / 4
        hour = int(categories[i].split(':')[0])
        
        # 檢查是否超約
        if hour_avg > contract_capacity:
            over_contract_times.append({
                'time': f"{hour:02d}:00-{(hour+1):02d}:00",
                'usage': round(hour_avg, 2),
                'over': round(hour_avg - contract_capacity, 2)
            })
        
        hourly_data.append({
            'hour': hour,
            'usage': hour_avg
        })
        max_usage = max(max_usage, hour_avg)
    logger.info(hourly_data)
    logger.info(f"最大用電量: {round(max_usage, 2)} kW")
    logger.info(f"契約容量: {contract_capacity} kW")
    
    # 檢查是否超
    if max_usage > contract_capacity:
        over_contract = max_usage - contract_capacity
        logger.warning(f"\n⚠️ 超約警告！")
        logger.warning(f"最大用電量: {round(max_usage, 2)} kW")
        logger.warning(f"契約容量: {contract_capacity} kW")
        logger.warning(f"超出契約容量: {round(over_contract, 2)} kW")
        logger.warning("\n超約時段：")
        for time_data in over_contract_times:
            logger.warning(f"時間: {time_data['time']}, 用電量: {time_data['usage']} kW, 超出: {time_data['over']} kW")
    else:
        logger.info(f"\n✅ 用電正常")
        logger.info(f"最大用電量: {round(max_usage, 2)} kW")
        logger.info(f"契約容量: {contract_capacity} kW")

    # 建立完整的時間序列
    times = []
    for hour in range(24):
        time = datetime.combine(target_date, datetime.min.time().replace(hour=hour))
        times.append(time)

    # 建立 DataFrame
    df = pd.DataFrame({
        'time': times,
        'usage': [data['usage'] for data in hourly_data]
    })

    # 判斷是否為夏月
    def is_summer(date):
        return (date.month == 5 and date.day >= 16) or (6 <= date.month <= 9) or (date.month == 10 and date.day <= 15)

    is_summer_day = is_summer(target_date)
    logger.info(f"計費期間: {'夏月' if is_summer_day else '非夏月'}")

    # 計算基本電費
    def calculate_basic_fee(is_summer):
        return contract_capacity * (basic_fee_summer if is_summer else basic_fee_non_summer)

    # 計算流動電費
    def calculate_electricity_charge(time, usage):
        is_summer_month = is_summer(time)
        day_of_week = time.weekday()
        hour = time.hour

        if day_of_week in range(0, 5):  # 週一至週五
            if is_summer_month and 16 <= hour < 22:
                rate = rate_table["peak"]["summer"]
                period = "尖峰"
            elif (is_summer_month and (9 <= hour < 16 or 22 <= hour < 24)) or \
                 (not is_summer_month and (6 <= hour < 11 or 14 <= hour < 24)):
                rate = rate_table["half_peak"]["summer" if is_summer_month else "non_summer"]["weekday"]
                period = "半尖峰"
            else:
                rate = rate_table["off_peak"]["summer" if is_summer_month else "non_summer"]
                period = "離峰"

        elif day_of_week == 5:  # 週六
            if (is_summer_month and 9 <= hour < 24) or \
               (not is_summer_month and (6 <= hour < 11 or 14 <= hour < 24)):
                rate = rate_table["half_peak"]["summer" if is_summer_month else "non_summer"]["saturday"]
                period = "半尖峰"
            else:
                rate = rate_table["off_peak"]["summer" if is_summer_month else "non_summer"]
                period = "離峰"

        else:  # 週日
            rate = rate_table["off_peak"]["summer" if is_summer_month else "non_summer"]
            period = "離峰"

        return usage * rate, period, rate

    # 計算總電費
    total_fee = 0
    total_basic_fee = calculate_basic_fee(is_summer_day)
    logger.info(f"基本電費: {round(total_basic_fee, 2)} 元")
    
    hourly_fees = []
    peak_usage = 0
    half_peak_usage = 0
    off_peak_usage = 0
    
    for index, row in df.iterrows():
        time = row['time']
        usage = row['usage']
        
        # 計算每小時的用電費用
        electricity_charge, period, rate = calculate_electricity_charge(time, usage)
        
        # 累計各時段用電量
        if period == "尖峰":
            peak_usage += usage
        elif period == "半尖峰":
            half_peak_usage += usage
        else:
            off_peak_usage += usage
            
        hourly_fees.append({
            'time': time.strftime('%H:00'),
            'usage': round(usage, 2),
            'fee': round(electricity_charge, 2),
            'period': period,
            'rate': rate
        })
        total_fee += electricity_charge

    usage_fee = total_fee
    total_fee += total_basic_fee

    logger.info(f"\n{'='*20} 用電統計 {'='*20}")
    logger.info(f"計費期間: {'夏月' if is_summer_day else '非夏月'}")
    logger.info(f"尖峰時段用電量: {round(peak_usage, 2)} kWh")
    logger.info(f"半尖峰時段用電量: {round(half_peak_usage, 2)} kWh")
    logger.info(f"離峰時段用電量: {round(off_peak_usage, 2)} kWh")
    
    logger.info(f"\n{'='*20} 電費計算 {'='*20}")
    logger.info(f"基本電費: {round(total_basic_fee, 2)} 元")
    logger.info(f"流動電費: {round(usage_fee, 2)} 元")
    logger.info(f"總電費: {round(total_fee, 2)} 元")
    logger.info(f"{'='*50}\n")

    # 修改返回的數據結構，加入 hourly_fees
    return {
        'total_fee': round(total_fee, 2),
        'basic_fee': round(total_basic_fee, 2),
        'usage_fee': round(usage_fee, 2),
        'hourly_fees': hourly_fees  # 添加每小時的詳細資料
    }

def monitor_status(request):
    current_time = datetime.now()
    
    # TimescaleDB 主要電表狀態檢查
    with connection.cursor() as cursor:
        cursor.execute("""
            SELECT COUNT(*)
            FROM "main_ht0"
            WHERE time >= now() - interval '5 minutes';
        """)
        timescale_count = cursor.fetchone()[0]

    # InfluxDB 狀態檢查
    client = InfluxDBClient('120.107.146.56', 8086, 'vendor01', 'q1a2z3wsx', 'Building_PV')
    
    # 太陽能發電表狀態
    pv_tables = {
        "HT4_1": "教學一二館",
        "HT5": "經世館",
        "HT6": "力行館",
        "HT7_9": "第十宿舍",
        "HT8": "工學院"
    }

    # 分支電表設定
    branch_meters = [
        {
            "name": "汙水處理廠",
            "database": "sensor_db",
            "table": "汙水處理廠HT1"
        },
        {
            "name": "教學一館",
            "database": "sensor_db",
            "table": "教學一錧MVCB"
        },
        {
            "name": "經世館",
            "database": "sensor_db",
            "table": "管理學院經世館HTM"
        },
        {
            "name": "力行館",
            "database": "sensor_db",
            "table": "力行館HT1"
        },
        {
            "name": "第十宿舍",
            "database": "dorm_db",
            "table": "第十宿舍MVCB"
        },
        {
            "name": "第九宿舍",
            "database": "dorm_db",
            "table": "第九宿舍HT1"
        },
        {
            "name": "工學院",
            "database": "sensor_db",
            "table": "工學院MCB"
        },
        {
            "name": "創新育成中心",
            "database": "sensor_db",
            "table": "育成中心MP1"
        }
    ]

    # 檢查太陽能發電表狀態
    pv_status = []
    for table_id, table_name in pv_tables.items():
        query = f"""
        SELECT COUNT(P_sum)
        FROM "{table_id}"
        WHERE time >= now() - 5m
        """
        result = client.query(query)
        points = list(result.get_points())
        count = points[0].get('count', 0) if points else 0
        
        pv_status.append({
            'id': table_id,
            'name': table_name,
            'status': count > 0,
            'last_update': current_time.strftime('%Y-%m-%d %H:%M:%S') if count > 0 else '無資料'
        })
    
    # 檢查分支電表狀態
    branch_status = []
    for meter in branch_meters:
        # 切換到對應的資料庫
        client = InfluxDBClient('120.107.146.56', 8086, 'vendor01', 'q1a2z3wsx', meter['database'])
        print(meter['database'])
        query = f"""
        SELECT COUNT(kPt)
        FROM "{meter['table']}"
        WHERE time >= now() - 5m
        """
        result = client.query(query)
        points = list(result.get_points())
        count = points[0].get('count', 0) if points else 0
        
        branch_status.append({
            'name': meter['name'],
            'database': meter['database'],
            'table': meter['table'],
            'status': count > 0,
            'last_update': current_time.strftime('%Y-%m-%d %H:%M:%S') if count > 0 else '無資料'
        })

    client.close()

    context = {
        'timescale_status': {
            'status': timescale_count > 0,
            'last_update': current_time.strftime('%Y-%m-%d %H:%M:%S') if timescale_count > 0 else '無資料'
        },
        'pv_status': pv_status,
        'branch_status': branch_status,
        'check_time': current_time.strftime('%Y-%m-%d %H:%M:%S')
    }
    
    return render(request, 'monitor_status.html', context)

def energy_storage_simulation(request):
    # 獲取選擇的日期
    selected_date = request.GET.get('date')
    if selected_date:
        target_date = datetime.strptime(selected_date, '%Y-%m-%d')
    else:
        target_date = datetime.now().replace(hour=0, minute=0, second=0, microsecond=0) - timedelta(days=5)

    # 設置查詢的開始和結束時間
    start_time = target_date
    end_time = target_date + timedelta(days=1)

    # 從 TimescaleDB 獲取主要電表數據
    with connection.cursor() as cursor:
        cursor.execute("""
            SET TIMEZONE = 'Asia/Taipei';
            SELECT time_bucket('15 minutes', time) AS time_bucket, 
                   ROUND(AVG(kpt)) AS avg_kpt
            FROM "main_ht0"
            WHERE time >= %s AND time < %s
            GROUP BY time_bucket
            ORDER BY time_bucket;
        """, [start_time, end_time])
        result = cursor.fetchall()

    categories = [row[0].strftime('%H:%M') for row in result]
    main_values = [row[1] for row in result]

    # 獲取 PV 發電量數據
    pv_values = query_influx_with_timezone_adjustment(start_time, end_time)

    # 計算總負載（主要電表 + PV發電量）
    if len(main_values) == len(pv_values):
        original_values = [main + pv for main, pv in zip(main_values, pv_values)]
    else:
        logger.error(f"數據長度不匹配: main_values={len(main_values)}, pv_values={len(pv_values)}")
        original_values = main_values
    
    logger.info(f"original_values: {original_values}")
    
    # 模擬儲能系統參數
    storage_capacity = 1260  # 儲能容量 (kWh)
    max_charge_rate = 200   # 最大充電功率 (kW)
    max_discharge_rate = 200  # 最大放電功率 (kW)
    efficiency = 0.9  # 充放電效率
    
    # 設定尖峰時段閾值
    peak_threshold = 600  # kW
    valley_threshold = 400  # kW

    # 初始化儲存列表
    storage_power = []  # 儲存每個時段的充放電功率
    adjusted_values = []  # 調節後的用電量
    storage_levels = []  # 記錄每個時段的儲能量
    storage_level = storage_capacity * 0.5  # 初始儲能量為50%

    for i, power in enumerate(original_values):
        # 獲取當前時間
        current_time = datetime.strptime(categories[i], '%H:%M')
        current_hour = current_time.hour
        
        # 判斷是否為離峰時段 (22:00-08:00)
        is_off_peak = current_hour >= 22 or current_hour < 8

        if power > peak_threshold and storage_level > 0:
            # 放電模式 - 任何時段都可以放電
            discharge_power = min(
                power - peak_threshold,
                max_discharge_rate,
                storage_level / 0.25
            )
            storage_level -= discharge_power * 0.25 / efficiency
            storage_power.append(-discharge_power)
            adjusted_values.append(power - discharge_power)
            
        elif power < valley_threshold and storage_level < storage_capacity and is_off_peak:
            # 充電模式 - 只在離峰時段充電
            charge_power = min(
                valley_threshold - power,
                max_charge_rate,
                (storage_capacity - storage_level) * 4 * efficiency
            )
            storage_level += charge_power * 0.25 * efficiency
            storage_power.append(charge_power)
            adjusted_values.append(power + charge_power)
            
        else:
            # 維持原狀
            storage_power.append(0)
            adjusted_values.append(power)
            
        storage_levels.append(storage_level)

    logger.info(f"adjusted_values: {adjusted_values}")

    # 計算效益分析
    peak_reduction = max(original_values) - max(adjusted_values)
    valley_filling = min(adjusted_values) - min(original_values)
    energy_shifted = sum(abs(p) * 0.25 for p in storage_power)

    # 計算原始負載和調節後負載的電費
    original_fee = calculate_hourly_electricity_fee(original_values, categories, target_date)
    adjusted_fee = calculate_hourly_electricity_fee(adjusted_values, categories, target_date)

    # 計算電費節省
    fee_saving = {
        'total_saving': round(original_fee['total_fee'] - adjusted_fee['total_fee'], 2),
        'original': {
            'total_fee': original_fee['total_fee'],
            'basic_fee': original_fee['basic_fee'],
            'usage_fee': original_fee['usage_fee'],
            'hourly_fees': original_fee['hourly_fees']
        },
        'adjusted': {
            'total_fee': adjusted_fee['total_fee'],
            'basic_fee': adjusted_fee['basic_fee'],
            'usage_fee': adjusted_fee['usage_fee'],
            'hourly_fees': adjusted_fee['hourly_fees']
        }
    }

    analysis = {
        'peak_reduction': round(peak_reduction, 2),
        'valley_filling': round(valley_filling, 2),
        'energy_shifted': round(energy_shifted, 2),
        'max_original': round(max(original_values), 2),
        'max_adjusted': round(max(adjusted_values), 2),
        'min_original': round(min(original_values), 2),
        'min_adjusted': round(min(adjusted_values), 2)
    }

    context = {
        'selected_date': target_date.strftime('%Y-%m-%d'),
        'chart_data': {
            'categories': categories,
            'original_values': original_values,
            'adjusted_values': adjusted_values,
            'storage_power': storage_power,
            'storage_levels': storage_levels
        },
        'analysis': analysis,
        'fee_saving': fee_saving
    }
    
    return render(request, 'energy_storage.html', context)

def prediction_storage_simulation(request):
    form = CSVUploadForm()
    context = {'form': form}

    if request.method == 'POST':
        form = CSVUploadForm(request.POST, request.FILES)
        if form.is_valid():
            csv_file = request.FILES['csv_file']
            df = pd.read_csv(csv_file, parse_dates=['Time'], index_col=[0])
            
            # 載入模型資訊
            model_info = joblib.load(settings.MODEL_INFO_PATH)
            
            # 載入模型和 scaler
            model = keras.models.load_model(settings.BASE_DIR / 'ml_models' / model_info['model_filename'])
            scaler = joblib.load(settings.BASE_DIR / 'ml_models' / model_info['scaler_filename'])
            
            # 獲取預測結果
            predictions, chart_data = PredictionView.predict(PredictionView, df, model, scaler)
            predictions=predictions[-96:]
            chart_data=json.loads(chart_data)[-96:]  # 解析JSON并获取最后96个点
            
            # 儲能系統參數
            storage_capacity = 1260  # 儲能容量 (kWh)
            max_charge_rate = 200   # 最大充電功率 (kW)
            max_discharge_rate = 200  # 最大放電功率 (kW)
            efficiency = 0.9  # 充放電效率
            
            # 設定尖峰時段閾值
            peak_threshold = 700  # kW
            valley_threshold = 250  # kW

            # 初始化儲存列表
            storage_power = []  # 儲存每個時段的充放電功率
            adjusted_values = []  # 調節後的用電量
            storage_levels = []  # 記錄每個時段的儲能量
            categories = []  # 時間類別

            # 每天重置儲能系統的初始狀態
            storage_level = storage_capacity * 0.5  # 初始儲能量為50%
            last_date = None

            for i, power in enumerate(predictions):
                # 使用chart_data中的时间戳
                timestamp = chart_data[i][0]
                current_date = datetime.fromtimestamp(timestamp/1000)
                
                # 如果是新的一天，重置儲能系統
                if last_date is not None and current_date.date() != last_date.date():
                    storage_level = storage_capacity * 0.5
                
                last_date = current_date
                categories.append(current_date.strftime('%Y-%m-%d %H:%M'))

                if power > peak_threshold and storage_level > 0:
                    # 放電模式
                    discharge_power = min(
                        power - peak_threshold,
                        max_discharge_rate,
                        storage_level * 4
                    )
                    storage_level -= discharge_power * 0.25 / efficiency
                    storage_power.append(-discharge_power)
                    adjusted_values.append(power - discharge_power)
                    
                elif power < valley_threshold and storage_level < storage_capacity:
                    # 充電模式
                    charge_power = min(
                        valley_threshold - power,
                        max_charge_rate,
                        (storage_capacity - storage_level) * 4 * efficiency
                    )
                    storage_level += charge_power * 0.25 * efficiency
                    storage_power.append(charge_power)
                    adjusted_values.append(power + charge_power)
                    
                else:
                    # 維持原狀
                    storage_power.append(0)
                    adjusted_values.append(power)
                    
                storage_levels.append(storage_level)

            # 計算效益分析
            peak_reduction = max(predictions) - max(adjusted_values)
            valley_filling = min(adjusted_values) - min(predictions)
            energy_shifted = sum(abs(p) * 0.25 for p in storage_power)

            # 計算原始負載和調節後負載的電費
            # 将时间格式转换为正确的格式
            formatted_categories = []
            for category in categories:
                # 将时间字符串转换为datetime对象
                dt = datetime.strptime(category, '%Y-%m-%d %H:%M')
                # 转换为正确的格式
                formatted_categories.append(dt.strftime('%H:%M'))

            original_fee = calculate_hourly_electricity_fee(predictions.tolist(), formatted_categories, current_date)
            adjusted_fee = calculate_hourly_electricity_fee(adjusted_values, formatted_categories, current_date)

            # 計算電費節省
            fee_saving = {
                'total_saving': round(original_fee['total_fee'] - adjusted_fee['total_fee'], 2),
                'original': {
                    'total_fee': original_fee['total_fee'],
                    'basic_fee': original_fee['basic_fee'],
                    'usage_fee': original_fee['usage_fee'],
                    'hourly_fees': original_fee['hourly_fees']
                },
                'adjusted': {
                    'total_fee': adjusted_fee['total_fee'],
                    'basic_fee': adjusted_fee['basic_fee'],
                    'usage_fee': adjusted_fee['usage_fee'],
                    'hourly_fees': adjusted_fee['hourly_fees']
                }
            }

            analysis = {
                'peak_reduction': round(peak_reduction, 2),
                'valley_filling': round(valley_filling, 2),
                'energy_shifted': round(energy_shifted, 2),
                'max_original': round(max(predictions), 2),
                'max_adjusted': round(max(adjusted_values), 2),
                'min_original': round(min(predictions), 2),
                'min_adjusted': round(min(adjusted_values), 2)
            }

            context.update({
                'chart_data': {
                    'categories': categories,
                    'original_values': predictions.tolist(),
                    'adjusted_values': adjusted_values,
                    'storage_power': storage_power,
                    'storage_levels': storage_levels
                },
                'analysis': analysis,
                'fee_saving': fee_saving,  # 添加電費節省數據
                'file_name': csv_file.name
            })

    return render(request, 'prediction_storage.html', context)

